import http from 'http';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { isStaticContent, serveStaticContent } from './static-content-serve.js';
import { login } from './login.js';
dotenv.config();

const handleRequestResponse=(request, response)=>{
    console.log('Request rec *****  ', request.url);
    let url = request.url;
    if(url ==='/'){
        url = '/index.html';
    }
    // Routing
    if(isStaticContent(url)){
        serveStaticContent(url, response);
    }
    else{
           if(url.startsWith('/dologin')){
                login(request, response);
           } 
           else if(url =='/register'){

           }
    }
    // isStatic or isDynamic
    
   // console.log('Handle Req and res');
    // response.write('<h1>Hello Node JS Server </h1>');
    // response.end();
}
const server = http.createServer(handleRequestResponse);
const serverConfig = server.listen(process.env.PORT || 9999, err=>{
    if(err){
        console.log(chalk.red.bold.underline('Unable to start the Server'));
    }
    else{
        console.log(chalk.green.bold.underline('Server Start... '+ serverConfig.address().port));
    }
})