import url from 'url';
export const login = (request, response)=>{
   const data =  request.url;
  // url.parse(data);
   const u = new URLSearchParams(data);
   const userInfo = [];
   for(let i of u.entries()){
    userInfo.push(i[1]);
   }
   response.setHeader('content-type', 'text/html');
   if(userInfo[0]==userInfo[1]){
    response.write('<h1>Welcome ' +userInfo[0]+' </h1>');
    response.end();
   }
   else{
    response.write('<h2>Invalid Userid or password </h2>');
    response.end();
   }
   console.log('I am on Login....', userInfo);
 
}