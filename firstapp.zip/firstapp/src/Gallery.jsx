// Animated Gif Images (Giphy)
import {data} from './data';
export const Gallery = ()=>{
    const arr = data();
    console.log('Data Rec is ......', arr);
    return (<h2>Image Gallery </h2>);
}