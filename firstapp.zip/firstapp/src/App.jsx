// What is Component
// Function (Arrow Function ES6) + JSX
import React from 'react';
import './App.css';
import { Gallery } from './Gallery';
 const App = ()=>{
  const name = 'Amit ';
  const myStyle = {
    width:'200px',
    height:'200px'
  }
  const time = 21;
  //const products = ['Puma', 'Nike', 'Bata','Relaxo'];
  const products = [{id:1001, name:'Puma Sport Shoes', price:2000, image:'https://assets.ajio.com/medias/sys_master/root/h40/h3e/16192820772894/-473Wx593H-460475907-black-MODEL.jpg'},
  {id:1002, name:'Nike Sport Shoes', price:12000, image:'https://c.static-nike.com/a/images/f_auto/dpr_3.0,cs_srgb/h_500,c_limit/g1ljiszo4qhthfpluzbt/123-joyride-cdp-apla-xa-xp.jpg'}
  ,{id:1003, name:'Bata Shoes', price:3000, image:'https://rukminim1.flixcart.com/image/850/1000/xif0q/shoe/e/n/h/-original-imaghvb9dpb4aeef.jpeg'}
  
]
  const greet = ()=>{
    if(time<12){
      return "Good Morning";
    }
    else if(time>=12 && time<=16){
      return "Good AfterNoon";
    }
    else if(time>16 && time<20){
      return "Good Evening";
    }
    else{
      return "Good Night";
    }
  }
  return (<div>
    <ul>
      {products.map(product=>{
        return (<li key={product.id}>
            <div>
              <img src={product.image} style = {myStyle}/>
              <p>{product.name}</p>
              <p>{product.price}</p>
            </div>
        </li>);
      })}
      {/* {products.map((product, index)=><li key={index} >{product}</li>)} */}
    </ul>
    <h1>Hello ReactJS</h1>
    <h2>Hi React JS</h2>
    <p>My Name is {name}</p>
    <p>{time>12?'Good AfterNoon':'Good Morning'}</p>
    <p>{greet()}</p>
    <hr/>
    <Gallery/>
    </div>);
 
 //return React.createElement('div', null,React.createElement('h1',null,'Hi React JS....'),  React.createElement('h2', null, 'This is H2')); 
  
}
export default App;