// What is Component
// Function (Arrow Function ES6) + JSX
import React from 'react';
import './App.css';
 const App = ()=>{
  return (<div>
    <h1>Hello ReactJS</h1>
    <h2>Hi React JS</h2>
    </div>);
 
 //return React.createElement('div', null,React.createElement('h1',null,'Hi React JS....'),  React.createElement('h2', null, 'This is H2')); 
  
}
export default App;