// Bridge File - App component HandShaking index.html
import App from './App';
import ReactDOM from 'react-dom/client';
// VDOM --> DOM
// DOM
const div = document.getElementById('root');
const root = ReactDOM.createRoot(div);
root.render(<App/>);