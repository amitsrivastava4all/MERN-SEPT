import express from 'express';
import { login, profile, register, remove } from '../controllers/user-controller.js';
export const userRoutes = express.Router();
userRoutes.post('/login', login);
userRoutes.post('/register', register);
userRoutes.post('/profile',profile);
userRoutes.post('/remove', remove);

