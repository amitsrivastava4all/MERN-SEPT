

export const register = (request, response)=>{
    response.end('<h1> Register </h1>');
}
export const login = (request, response)=>{
    response.end('<h1> Login </h1>');
}
export const profile = (request, response)=>{

}
export const remove = (request, response)=>{

}
