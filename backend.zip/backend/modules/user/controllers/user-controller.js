import { userService } from "../services/user-service.js";
import {AppConstants} from '../../../shared/utils/constants/config.js';
import { loadMessageBundle } from "../../../shared/utils/i18n/message-reader.js";
const {FILE_NOT_FOUND, SERVER_INTERNAL_ERROR} = AppConstants.ERROR_CODES;
const {SUCCESS_CODE} = AppConstants;
const loadBundle = ()=>{
    const messages = loadMessageBundle();
    return messages;
}
export const register = async (request, response)=>{
    
    const userData = request.body;
    console.log('JSON Data ', userData);
    try{
    const doc = await userService.register(userData);
    if(doc._id){
        response.json({
            "message":"Register SuccessFully", "doc":doc
        })
    }
    else{
        response.json({"message":"Problem During Register"});
    }
    }
    catch(err){
        console.log('Error is ', err);
        response.json({"message":"Error During Register"});
    }
    //response.end('<h1> Register </h1>');
    
}
export const login = async (request, response)=>{
    const messages = loadBundle();
    const userData = request.body;
    try{
    const result = await userService.login(userData);
    if(result && result.name){
        response.status(SUCCESS_CODE).json({"message":messages['login.success'], "name":result.name});
    }
    else{
        response.status(FILE_NOT_FOUND).json({"message":messages['login.fail']});
    }
}
catch(err){
    response.status(SERVER_INTERNAL_ERROR).json({"message":"Some Error in Login"});
    console.log(err); 
}
    //response.end('<h1> Login </h1>');
}
export const profile = (request, response)=>{

}
export const remove = (request, response)=>{

}
// mongosh "mongodb+srv://usermanagement-cluster.n0thobu.mongodb.net/" --apiVersion 1 --username adminuser