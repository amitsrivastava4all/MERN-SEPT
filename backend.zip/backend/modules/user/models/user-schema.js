import { SchemaTypes, Schema } from 'mongoose';
import mongoose from '../../../shared/db/connection.js';
import {AppConstants} from '../../../shared/utils/constants/config.js';
const {USER_SCHEMA} = AppConstants.SCHEMAS;
const userSchema = new Schema({
    'email':{type:SchemaTypes.String, required:true, unique:true},
    'password':{type:SchemaTypes.String, maxLength:70, minLength:8, required:true},
    'name':{type:SchemaTypes.String, required:true}
});
export const UserModel = mongoose.model(USER_SCHEMA, userSchema);


