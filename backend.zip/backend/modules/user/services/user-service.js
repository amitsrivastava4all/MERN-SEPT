import { comparePassword, passwordHashing } from "../../../shared/utils/password-hash.js";
import { UserModel } from "../models/user-schema.js"

export const userService = {
    async register(userData) {
        try{
            userData.password = passwordHashing(userData.password);
        const doc = await UserModel.create(userData);
        return doc;
        }
        catch(err){
            throw err; 
        }
       
    },
    async login(userData){
        try{
        const doc = await UserModel.findOne({"email":userData.email})
        .select("name password -_id").exec();
            console.log('Login Doc ', doc);
        if(doc && doc.name){
            const hashPassword = doc.password;
            const plainPassword = userData.password;
            if(comparePassword(plainPassword, hashPassword)){
                return {name:doc.name};
            }
            else{
                return null;
            }
            // Check for Password
        }
        else{
            // email not found
            return null;
        }
        }
        catch(err){
            throw err;
        }
    }

}