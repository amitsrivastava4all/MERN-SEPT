export const Caps = ()=>{
    return (<h2>Caps....</h2>)
}