export const Error = ()=>{
    return (<h3>OOPS U Type Something Wrong...</h3>)
}