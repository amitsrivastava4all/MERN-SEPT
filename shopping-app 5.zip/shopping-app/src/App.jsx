import { Header } from "./components/Header";
import { Home } from "./components/Home";
import {Routes, Route} from 'react-router-dom';
import { Shoes } from "./components/Shoes";
import { Shirts } from "./components/Shirts";
import { Caps } from "./components/Caps";
import { Error } from "./components/Error";
import { TotalItemsInCart } from "./components/TotalItemsInCart";
const App = ()=>{
  return (<>
  <Header/>
    <Routes>
      <Route path="/"  element={<Home/>}/>
      <Route path="/shoes/:type/:price"  element={<Shoes/>}/>
      <Route path="/shirts"  element={<Shirts/>}/>
      <Route path="/caps"  element={<Caps/>}/>
      <Route path="/total-cart"  element={<TotalItemsInCart/>}/>
      <Route path="*" element={<Error/>}/>
    </Routes>
  
  </>);
}
export default App;