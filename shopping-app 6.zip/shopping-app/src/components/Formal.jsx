export const Formal = ()=>{
    return (<h3>Formal Caps</h3>)
}