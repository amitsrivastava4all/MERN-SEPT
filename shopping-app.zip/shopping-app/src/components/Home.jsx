import { getProducts } from "../utils/api-client"

export const Home = ()=>{
    getProducts();
    return (<h1 className='alert alert-info text-center'>Welcome to the Shopping App</h1>)
}