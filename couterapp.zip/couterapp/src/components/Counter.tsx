import React from "react";

interface Iprops {
  data: number;
}

interface Login {
  email: string;
  password: string;
  date: Date;
  age: [];
}

const Counter: React.FC<Iprops> = () => {
  const [value, setValue] = React.useState<number>(0);
  return (
    <>
      <h1>{value}</h1>
      <input
        onChange={(e) => {
          setValue(parseInt(e.target.value));
        }}
      />
    </>
  );
};

export default Counter;
