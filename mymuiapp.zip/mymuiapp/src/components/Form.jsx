import { Box, Button, TextField, Typography } from "@mui/material";
import React from "react";

const Form = () => {
  return (
    <>
      <Box>
        <Typography>Login</Typography>

        <TextField />
        <Button></Button>
      </Box>
    </>
  );
};

export default Form;
