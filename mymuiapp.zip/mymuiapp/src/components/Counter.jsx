import { Box, Button, TextField, Typography } from "@mui/material";
import React from "react";

const Counter = () => {
  const [value, setValue] = React.useState(0);

  return (
    <Box
      display={"flex"}
      justifyContent={"center"}
      alignItems={"center"}
      height={"100vh"}
      width={"100%"}
    >
      <Box>
        <Typography variant="caption">{value}</Typography>
        <TextField
          type="text"
          fullWidth
          variant="filled"
          onChange={(e) => {
            setValue(e.target.value);
          }}
        />
        <Button
          onClick={() => {
            setValue(value + 1);
          }}
          variant="text"
        >
          + Increment
        </Button>
        <Button
          onClick={() => {
            setValue(0);
          }}
          variant="contained"
          color="primary"
        >
          Reset
        </Button>
        <Button
          onClick={() => {
            setValue(value - 1);
          }}
          variant="outlined"
          color="success"
        >
          - Decrement
        </Button>
      </Box>
    </Box>
  );
};

export default Counter;
