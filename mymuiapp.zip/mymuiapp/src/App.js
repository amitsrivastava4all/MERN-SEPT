import SearchAppBar from "./components/AppBar";
import Counter from "./components/Counter";
import Form from "./components/Form";

function App() {
  return (
    <>
      <SearchAppBar />
      <Counter />
    </>
  );
}

export default App;
