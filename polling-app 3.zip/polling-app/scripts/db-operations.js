import { db } from "./firebase-config.js"
import {  addDoc ,collection} from "https://www.gstatic.com/firebasejs/10.5.2/firebase-firestore-compat.js";
/*
import { collection, addDoc } from "firebase/firestore"; 

// Add a new document with a generated id.
const docRef = await addDoc(collection(db, "cities"), {
  name: "Tokyo",
  country: "Japan"
});
console.log("Document written with ID: ", docRef.id);
*/
export const dbOperations = {
    addQuestion(questionObject){
        // Async Prg
            addDoc(collection(db,'questions'), questionObject); // Assign to Async Thread
            console.log('Add Done...');
    }
}