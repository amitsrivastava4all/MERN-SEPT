const App = ()=>{
  let count = 0;
  const plus = ()=>{
    count++;
    console.log('Plus Call ', count);
   
  }
  return (<div>
    <h1>Counter App</h1>
    <h2>Count Value is {count}</h2>
    <button onClick= {plus} >+</button>


  </div>)
}
export default App;

