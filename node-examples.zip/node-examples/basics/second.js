var a= 10;
var b = 20;
setTimeout(()=>console.log('I Run After 3 Sec'), 3000);
var c = a + b;
console.log('Sum is ', c);