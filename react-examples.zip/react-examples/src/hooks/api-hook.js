import axios from 'axios';
import { useEffect, useState } from 'react';
export const useApi =  (URL)=>{
    
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState(null);
    const [err, setError] = useState(null);
    const getNews = async ()=>{
        try{
            const response = await axios.get(URL);
            setLoading(false);
            console.log('Response ', response);
            setData(response.data);
            
            }
            catch(err){
                setError(err);
            }
    }
    // State for Loading, FullFilled, Rejected
    useEffect( ()=>{
        getNews();
    },[]);
   // console.log('******** ',loading, data, err);
    return {loading, data, err};
}