import axios from 'axios';
export const interceptorOn = ()=>{
    console.log('Interceptor On....')
    axios.interceptors.request.use(function (request) {
        // Do something before request is sent
        console.log('Interceptor Request......');
        request.headers['token'] = 'A1111';
        return request;
      }, function (error) {
        // Do something with request error
        return Promise.reject(error);
      });
      axios.interceptors.response.use(function(config){
        return response;
      })
}