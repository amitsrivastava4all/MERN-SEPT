import A from "./A";
import { useState } from "react";
export const Hoc = (WrappedComponent)=>{
   
    const x = 100;
    const newComponent = ()=>{
        const [counter, setCounter] = useState(0);
        return (<>
        <h1> I am the Super Component {x} Count is {counter} </h1>
        <button onClick={()=>{
            setCounter(counter + 1);
        }}>Plus</button>
        <WrappedComponent count= {counter}/>
        </>);
    }
    return newComponent;
}