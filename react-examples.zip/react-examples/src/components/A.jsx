import React from 'react'
import { Hoc } from './Hoc'

const A = ({count}) => {
  return (
    <div>
        <p>I am the A Component... {count}</p>
    </div>
  )
}

export default Hoc(A);