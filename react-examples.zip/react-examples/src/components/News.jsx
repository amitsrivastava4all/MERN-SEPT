import React from 'react'
import { useApi } from '../hooks/api-hook'

export const News = () => {
    const mystyle = {width:'100px', height:'100px'};
    // Call useApi Hook (States....)
    const {loading, data, err} = useApi(import.meta.env.VITE_NEWS_URL);
  return (
    <div>
        <p>{loading && <span>Loading.....</span>}</p>
        <h1>News App</h1>
        {data && data.articles.map(obj=><p>{obj.title} <img style = {mystyle} src={obj.urlToImage}/></p>)}
        {err && <p>Error Coming...</p>}
        {/* Based on State we render UI */} 
    </div>
  )
}
