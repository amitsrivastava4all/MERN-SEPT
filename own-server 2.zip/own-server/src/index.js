import http from 'http';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { isStaticContent, serveStaticContent } from './static-content-serve.js';
import { doRegister, login } from './login.js';
import { heavy } from './heavy.js';
import cluster from 'cluster';
import os from 'os';
import https from 'https';
import fs from 'fs';
console.log('My Machine has CPU '+os.cpus().length);
dotenv.config();

const handleRequestResponse=(request, response)=>{
    console.log('Request rec *****  ', request.url);
    let url = request.url;
    const method = request.method;
    if(url ==='/'){
        url = '/index.html';
    }
    // Routing
    if(isStaticContent(url)){
        serveStaticContent(url, response);
    }
    else{
           if(url.startsWith('/dologin') && method==='GET'){
                login(request, response);
           } 
           else if(url ==='/doregister' && method === 'POST'){
                doRegister(request, response);
           }
           else if(url ==='/heavy'){
                heavy(request, response);
           }
    }
    // isStatic or isDynamic
    
   // console.log('Handle Req and res');
    // response.write('<h1>Hello Node JS Server </h1>');
    // response.end();
}

// Cluster Master
if(cluster.isPrimary){
 // start the workers
 const cores = os.cpus().length;
 for(let i = 1; i<=cores; i++){
    cluster.fork(); // create instance of worker
    cluster.on('online', worker=>{
        console.log('Worker Online ', worker.id, worker.process.id);
    })
 }
}
else{
    const certOptions= {
        key : fs.readFileSync('./cert/key.pem'),
        cert:fs.readFileSync('./cert/cet.pem')
    }
    console.log('Worker Up and Running ', cluster.isWorker, cluster.worker.id);
    const server = https.createServer(certOptions,handleRequestResponse);
const serverConfig = server.listen(process.env.PORT || 9999, err=>{
    if(err){
        console.log(chalk.red.bold.underline('Unable to start the Server'));
    }
    else{
        console.log(chalk.green.bold.underline('Server Start... '+ serverConfig.address().port));
    }
})
}

