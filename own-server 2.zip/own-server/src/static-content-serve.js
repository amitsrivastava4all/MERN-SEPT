import { getCurrentDir } from "./utils.js";
import path from 'path';
import fs from 'fs';

// Serve Static Contents
export const isStaticContent = (url)=>{
    const extensions = [".js", ".css", ".ico",".jpeg","jpg",".png",".html"];
    const ext = path.extname(url);
    console.log('!!!!! Ext is ', ext);
    return extensions.indexOf(ext)>=0;
}
export const serveStaticContent  =(url, response)=>{
    console.log('Server Static Content Call ');
    const __dirname = getCurrentDir();
    response.setHeader('content-type', 'text/html');
   
    if(url ==='/'){ // Home Page (index.html)
        //response.writeHead(200, {'Content-Type':'text/html'});
        const rootDir = path.normalize(__dirname+"/..");
        const fullPath = path.join(rootDir,'/public/index.html');
        const readStream = fs.createReadStream(fullPath);
        readStream.pipe(response);
        readStream.on('end',()=>{
            response.end();
        })

    }
    else{
        const rootDir = path.normalize(__dirname+"/..");
        const fullPath = path.join(rootDir,'/public/'+url);
        const extensions = [".js", ".css", ".ico",".jpeg","jpg",".png",".html"];
        console.log('Full Path is ', fullPath);
        const ext = path.extname(fullPath);
        let currentMime = ext.split(".")[1];
        currentMime = `text/${currentMime}`;
        console.log(currentMime+ " Mime TYPE");
        //response.setHeader('content-type', currentMime.toString());
        //response.writeHead(200, {'Content-Type':currentMime});
        //response.headers['content-type']= currentMime;
        if(ext=='.js'){
            response.setHeader('content-type', 'text/javascript');
        }
        else if(ext =='.css'){
            response.setHeader('content-type', 'text/css');
        }
        console.log('Ext is ', ext);
        if(extensions.indexOf(ext)>=0){
            // Static File
            const readStream = fs.createReadStream(fullPath);
        readStream.pipe(response);
        readStream.on('end',()=>{
            response.end();
        })
        }
        else{
            // Dynamic 
        }
    }
}