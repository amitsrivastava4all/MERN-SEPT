export const heavy = (request, response)=>{
    for(let i = 1; i<=100000; i++){
        for(let j = 1; j<=500000; j++){

        }
    }
    console.log('Heavy Task Done....');
    response.write('<h1>Heavy Task Done....</h1>');
    response.end();
}