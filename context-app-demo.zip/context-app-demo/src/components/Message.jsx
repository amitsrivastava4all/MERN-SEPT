import { useContext } from "react"
import { CounterContext } from "../context/counter-context"

export const Message = ({msg, flag='S'})=>{
    const context = useContext(CounterContext);
    if(flag=='H'){
        return (<h1 className='alert alert-info text-center'>{msg}</h1>);
    }
    return (<h3 className='alert alert-success'>{msg}{context.countValue} </h3>)
}