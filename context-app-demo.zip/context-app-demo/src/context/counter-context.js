import  { createContext } from "react";
// React.createContext
export const CounterContext = createContext({countValue:0, updateCount:function(){}})