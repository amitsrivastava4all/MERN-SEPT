import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { addPermission } from "../services/api-client.js";

const initialState = {
  permissions: [],
  status: "idle",
  error: null,
};

export const addNewPermission = createAsyncThunk(
  "permission/addNewPermission",
  async (permissionData, { rejectWithValue }) => {
    try {
      const newPermission = await addPermission(permissionData);
      return newPermission;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const permissionSlice = createSlice({
  name: "permission",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addNewPermission.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addNewPermission.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.permissions.push(action.payload);
      })
      .addCase(addNewPermission.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export default permissionSlice.reducer;
