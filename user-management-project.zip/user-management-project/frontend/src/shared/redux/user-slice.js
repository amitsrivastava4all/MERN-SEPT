import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { delUser, register } from "../services/api-client.js"; // Assume remove is a function that handles deleting a user

export const addNewUser = createAsyncThunk(
  "user/addNewUser",
  async (userData, thunkAPI) => {
    try {
      const newUser = await register(userData);
      return newUser;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

export const deleteUser = createAsyncThunk(
  "user/deleteUser",
  async (userId, thunkAPI) => {
    try {
      await delUser(userId);
      return userId;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState: {
    users: [],
    status: "idle",
    error: null,
  },
  reducers: {
    addUserSuccess: (state, action) => {
      state.users.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(addNewUser.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addNewUser.fulfilled, (state, action) => {
        state.status = "success";
        state.users.push(action.payload);
      })
      .addCase(addNewUser.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(deleteUser.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteUser.fulfilled, (state, action) => {
        state.status = "success";
        state.users = state.users.filter((user) => user.id !== action.payload);
      })
      .addCase(deleteUser.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const { addUserSuccess } = userSlice.actions;

export default userSlice.reducer;
