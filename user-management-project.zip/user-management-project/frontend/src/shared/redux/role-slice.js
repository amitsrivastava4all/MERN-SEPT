import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { addRole } from "../services/api-client.js";

const initialState = {
  roles: [],
  status: "idle",
  error: null,
};

export const addNewRole = createAsyncThunk(
  "role/addNewRole",
  async (roleData, { rejectWithValue }) => {
    try {
      const newRole = await addRole(roleData);
      return newRole;
    } catch (error) {
      console.log(error.message, "This in in think");
      return rejectWithValue(error.message);
    }
  }
);

const roleSlice = createSlice({
  name: "role",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(addNewRole.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addNewRole.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.roles.push(action.payload);
      })
      .addCase(addNewRole.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export default roleSlice.reducer;
