// api-client.js
import axios from "axios";

const API_BASE_URL = "http://localhost:7777"; // Replace with your backend API URL

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Authentication
export const login = async (credentials) => {
  const response = await apiClient.post("/login", credentials, {
    withCredentials: true,
  });
  return response.data;
};
export const logout = async () => {
  const response = await apiClient.post(
    "/logout",
    {},
    {
      withCredentials: true,
    }
  );
  return response.data;
};
export const verifyToken = async () => {
  const response = await apiClient.get("/token-verify", {
    withCredentials: true,
  });
  return response.data;
};

export const register = async (userData) => {
  const response = await apiClient.post("/register", userData, {
    withCredentials: true,
  });
  return response.data;
};
export const delUser = async (userId) => {
  const response = await apiClient.delete(`/delete-user/${userId}`, {
    withCredentials: true,
  });
  return response.data;
};

// User Management
export const addRole = async (role) => {
  const response = await apiClient.post("/roles", role, {
    withCredentials: true,
  });
  console.log("The Client ", response);
  return response.data;
};

export const changePassword = async (userData) => {
  const response = await apiClient.put("/change-password", userData, {
    withCredentials: true,
  });
  return response.data;
};

export const resetPassword = async (userData) => {
  const response = await apiClient.post("/users/resetPassword", userData);
  return response.data;
};

export const getAllUsers = async () => {
  const response = await apiClient.get("/all-users", {
    withCredentials: true,
  });
  return response.data;
};

export const getRoles = async () => {
  const response = await apiClient.get("/roles");
  return response.data;
};

export const deleteRole = async (roleId) => {
  const response = await apiClient.delete(`/roles/${roleId}`);
  return response.data;
};

export const editRole = async (roleId, updatedRole) => {
  const response = await apiClient.put(`/roles/${roleId}`, updatedRole);
  return response.data;
};

export const getPermissions = async () => {
  const response = await apiClient.get("/permissions");
  return response.data;
};

export const addPermission = async (permission) => {
  const response = await apiClient.post("/permissions", permission, {
    withCredentials: true,
  });
  return response.data;
};

export const deletePermission = async (permissionId) => {
  const response = await apiClient.delete(`/permissions/${permissionId}`);
  return response.data;
};

export const editPermission = async (permissionId, updatedPermission) => {
  const response = await apiClient.put(
    `/permissions/${permissionId}`,
    updatedPermission
  );
  return response.data;
};
