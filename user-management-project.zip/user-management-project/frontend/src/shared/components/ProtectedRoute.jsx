// ProtectedRoute.js
import { useContext } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { AuthContext } from "../../AuthContext";

// eslint-disable-next-line react/prop-types
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, isAuthenticated } = useContext(AuthContext);
  const location = useLocation();


  const userRoles = user?.user?.role.map((role) => role.name);

  if (
    !isAuthenticated ||
    // eslint-disable-next-line react/prop-types
    (allowedRoles && !allowedRoles.some((role) => userRoles.includes(role)))
  ) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};

export default ProtectedRoute;
