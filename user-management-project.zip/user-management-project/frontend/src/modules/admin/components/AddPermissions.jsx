import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Box, TextField, Button, Typography } from "@mui/material";
import { toast } from "react-toastify";
import { addNewPermission } from "../../../shared/redux/permission-slice";

const AddPermission = () => {
  const dispatch = useDispatch();
  const AddPermissionStatus = useSelector((state) => state.permission.status);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newPermission = { name, desc };
    const resultAction = await dispatch(addNewPermission(newPermission));
    if (addNewPermission.fulfilled.match(resultAction)) {
      toast.success("Permission Added Successfully");
    } else if (AddPermissionStatus === "failed") {
      toast.error(
        `Error: ${resultAction.payload || "Failed to add permission"}`
      );
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      minHeight="100vh"
      bgcolor="background.default"
    >
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          maxWidth: 400,
          padding: 4,
          bgcolor: "background.paper",
          borderRadius: 2,
          boxShadow: 3,
        }}
      >
        <Typography variant="h5" gutterBottom>
          Add Permission
        </Typography>
        <TextField
          label="Permission Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          margin="normal"
          required
        />
        <TextField
          label="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          margin="normal"
          required
        />
        <Button
          type="submit"
          variant="contained"
          color="primary"
          sx={{ marginTop: 2 }}
        >
          Add Permission
        </Button>
      </Box>
    </Box>
  );
};

export default AddPermission;
