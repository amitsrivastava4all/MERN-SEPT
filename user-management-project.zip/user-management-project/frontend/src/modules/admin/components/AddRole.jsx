import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Box,
  TextField,
  Button,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import { toast } from "react-toastify";
import { addNewRole } from "../../../shared/redux/role-slice";

const AddRole = () => {
  const dispatch = useDispatch();
  const AddRoleStatus = useSelector((state) => state.role.status);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [selectedPermissions, setSelectedPermissions] = useState([]);

  const permissions = ["GetUser", "EditUser", "AddUser"];

  const handlePermissionsChange = (event) => {
    const { value } = event.target;
    setSelectedPermissions(
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newRole = { name, desc, permissions: selectedPermissions };
    const resultAction = await dispatch(addNewRole(newRole));
    if (addNewRole.fulfilled.match(resultAction)) {
      toast.success("Role Added Successfully");
    } else if (AddRoleStatus === "failed") {
      console.log("result action", resultAction);
      toast.error(`Error: ${resultAction.payload || "Failed to add role"}`);
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      minHeight="100vh"
      bgcolor="background.default"
    >
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          maxWidth: 400,
          padding: 4,
          bgcolor: "background.paper",
          borderRadius: 2,
          boxShadow: 3,
        }}
      >
        <Typography variant="h5" gutterBottom>
          Add Role
        </Typography>
        <TextField
          label="Role Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          margin="normal"
          required
        />
        <TextField
          label="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          margin="normal"
          required
        />
        <FormControl fullWidth margin="normal">
          <InputLabel id="permissions-label">Permissions</InputLabel>
          <Select
            labelId="permissions-label"
            multiple
            value={selectedPermissions}
            onChange={handlePermissionsChange}
            renderValue={(selected) => selected.join(", ")}
          >
            {permissions.map((permission) => (
              <MenuItem key={permission} value={permission}>
                {permission}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button
          type="submit"
          variant="contained"
          color="primary"
          sx={{ marginTop: 2 }}
        >
          Add Role
        </Button>
      </Box>
    </Box>
  );
};

export default AddRole;
