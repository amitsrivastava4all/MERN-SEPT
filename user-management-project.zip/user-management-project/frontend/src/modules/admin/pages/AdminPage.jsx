// import { Profile } from "../components/Profile"
// import { Register } from "../components/Register";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import TabPanel from "@mui/lab/TabPanel";
import TabContext from "@mui/lab/TabContext";
import { useContext, useState } from "react";
import AddUser from "../components/AddUser.jsx";
import AddRole from "../components/AddRole.jsx";
import AddPermission from "../components/AddPermissions.jsx";
import { logout } from "../../../shared/services/api-client.js";
import { AuthContext } from "../../../AuthContext.jsx";
import UserList from "./UserList.jsx";
// import Box from '@mui/material/Box';
const UserPage = () => {
  const [value, setValue] = useState(0);
  const { logoutContext } = useContext(AuthContext);

  const tabChange = (event, newValue) => {
    setValue(newValue);
  };

  const logoutUser = async () => {
    await logout();
    logoutContext();
    window.reload();
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Admin Panel
          </Typography>
          <Button color="inherit" onClick={logoutUser}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>
      <TabContext value={value}>
        <Tabs onChange={tabChange} aria-label="basic tabs example">
          <Tab label="Add User" value="0" />
          <Tab label="Remove User" value="1" />
          <Tab label="Add Role" value="2" />
          <Tab label="Add Permission" value="3" />
        </Tabs>
        <TabPanel value="0">
          <AddUser />
        </TabPanel>
        <TabPanel value="1">
          <UserList />
        </TabPanel>
        <TabPanel value="2">
          <AddRole />
        </TabPanel>
        <TabPanel value="3">
          <AddPermission />
        </TabPanel>
      </TabContext>
    </>
  );
};

export default UserPage;
