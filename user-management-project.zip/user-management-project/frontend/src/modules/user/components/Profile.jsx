export const Profile = ()=>{
    return (<>
        <p>Profile</p>
    </>)
}