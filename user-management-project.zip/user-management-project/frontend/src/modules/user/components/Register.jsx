import { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useRef } from "react";
// import { postData } from '../../../shared/services/api-client';
export const Register = () => {
  const [showPassword, setShowPassword] = useState(false);
  // const [message, setMessage] = useState('');
  const email = useRef("");
  const password = useRef("");
  const name = useRef("");

  const doRegister = async () => {
    const userInfo = {
      email: email.current.value,
      name: name.current.value,
      password: password.current.value,
    };
    console.log("Do Register  ", userInfo);
    // try{
    // const result = await postData('http://localhost:7777/register',userInfo);
    // setMessage(result.data.message);
    // console.log('Result is ', result);
    // }
    // catch(err){
    //   console.log('Error in Register... ', err);
    // }
  };

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  return (
    <>
      <p>Register</p>
      {/* <p>{message}</p> */}
      <TextField
        inputRef={email}
        id="outlined-basic"
        label="Email"
        variant="outlined"
      />
      <br />
      <TextField
        inputRef={name}
        id="outlined-basic"
        label="Name"
        variant="outlined"
      />
      <br />
      <OutlinedInput
        inputRef={password}
        id="outlined-adornment-password"
        type={showPassword ? "text" : "password"}
        endAdornment={
          <InputAdornment position="end">
            <IconButton
              aria-label="toggle password visibility"
              onClick={handleClickShowPassword}
              edge="end"
            >
              {showPassword ? <VisibilityOff /> : <Visibility />}
            </IconButton>
          </InputAdornment>
        }
        label="Password"
      />
      <br />
      <Button onClick={doRegister} variant="contained">
        Register
      </Button>
      &nbsp;
      <Button variant="contained">Clear All</Button>
    </>
  );
};
