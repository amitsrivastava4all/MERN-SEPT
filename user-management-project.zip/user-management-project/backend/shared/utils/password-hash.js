import bcrypt from "bcrypt";
const SALT = 10;
export const passwordHashing = (plainPassword) => {
  const hashPassword = bcrypt.hash(plainPassword, SALT);
  console.log(
    "Plain Password ",
    plainPassword,
    " Hash Password ",
    hashPassword
  );
  return hashPassword;
};
export const comparePassword = (plainPassword, hashPassword) => {
  return bcrypt.compare(plainPassword, hashPassword);
};
