import { RoleModel } from "../models/role-schema.js";
import { catchError } from "../../../middlewares/catchError.js";
import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { roleService } from "../services/role-service.js";
// import { roleService } from "../services/role-service.js";

export const createRole = catchError(async (req, res, next) => {
  const roleData = req.body;
  try {
    const newRole = await roleService.createRole({
      ...roleData,
      userId: req.user._id,
    });
    res.status(201).json({
      message: "Role created successfully",
      role: newRole,
    });
  } catch (error) {
    res.status(501).json({
      message: error.message,
      role: null, 
    });
  }
});

export const getRoles = catchError(async (req, res, next) => {
  try {
    const roles = await roleService.getRoles();
    res.status(200).json({ roles });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const updateRole = catchError(async (req, res, next) => {
  const roleId = req.params.id;
  const updatedData = req.body;
  try {
    const updatedRole = await roleService.updateRole(roleId, updatedData);
    res
      .status(200)
      .json({ message: "Role updated successfully", role: updatedRole });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const deleteRole = catchError(async (req, res, next) => {
  const roleId = req.params.id;
  try {
    await roleService.deleteRole(roleId);
    res.status(200).json({ message: "Role deleted successfully" });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const assignPermissionsToRole = catchError(async (req, res, next) => {
  const roleId = req.params.id;
  const permissionNames = req.body.permissions;
  try {
    const updatedRole = await roleService.assignPermissionsToRole(
      roleId,
      permissionNames
    );
    res.status(200).json({
      message: "Permissions assigned to role successfully",
      role: updatedRole,
    });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});
