import { catchError } from "../../../middlewares/catchError.js";
import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { permissionService } from "../services/permission-service.js";

export const createPermission = catchError(async (req, res, next) => {
  const permissionData = req.body;
  try {
    const newPermission = await permissionService.createPermission(
      permissionData
    );
    res.status(201).json({
      message: "Permission created successfully",
      permission: newPermission,
    });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const getPermissions = catchError(async (req, res, next) => {
  try {
    const permissions = await permissionService.getPermissions();
    res.status(200).json({ permissions });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const updatePermission = catchError(async (req, res, next) => {
  const permissionId = req.params.id;
  const updatedData = req.body;
  try {
    const updatedPermission = await permissionService.updatePermission(
      permissionId,
      updatedData
    );
    res.status(200).json({
      message: "Permission updated successfully",
      permission: updatedPermission,
    });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});

export const deletePermission = catchError(async (req, res, next) => {
  const permissionId = req.params.id;
  try {
    await permissionService.deletePermission(permissionId);
    res.status(200).json({ message: "Permission deleted successfully" });
  } catch (error) {
    next(new ErrorHandler(error.message, error.statusCode || 500));
  }
});
