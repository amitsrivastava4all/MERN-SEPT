import { userService } from "../services/user-service.js";
import { AppConstants } from "../../../shared/utils/constants/config.js";
import jwt from "jsonwebtoken";
import { loadMessageBundle } from "../../../shared/utils/i18n/message-reader.js";
// import { generateToken, verifyToken } from "../../../shared/utils/token.js";
import { catchError } from "../../../middlewares/catchError.js";
import ErrorMiddleWare from "../../../middlewares/Error.js";
import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { sendToken } from "../../../shared/utils/sendToken.js";
import { RoleModel } from "../models/role-schema.js";
import { UserModel } from "../models/user-schema.js";
const { FILE_NOT_FOUND, SERVER_INTERNAL_ERROR, AUTH_FAIL } =
  AppConstants.ERROR_CODES;
const { SUCCESS_CODE } = AppConstants;
const loadBundle = () => {
  const messages = loadMessageBundle();
  return messages;
};
export const register = catchError(
  async (request, response, next) => {
    const userData = request.body;
    if (userData.email == null && userData.password == null) {
      return next(new ErrorHandler("Please Enter All Fields", 400));
    }
    const doc = await userService.register(userData);
    if (!doc) return next(new ErrorHandler("User Already Exists"), 409);
    sendToken(response, doc, "Registered Successfully", 201);
  }
  //response.end('<h1> Register </h1>');
);

export const login = async (request, response, next) => {
  const messages = loadBundle();
  const { email, password } = request.body;
  if (!email || !password)
    return next(new ErrorHandler("Please Enter All Fields", 400));

  try {
    const user = await userService.login(email, password);

    if (!user) return next(new ErrorHandler("User Not Exists", 401));

    sendToken(response, user, `Welcome back ${user.name}`, 201);
  } catch (error) {
    response.send(new ErrorHandler(error.message, 500));
  }
};

export const logout = async (request, response, next) => {
  try {
    response.clearCookie("token");
    response.status(200).json({ message: "Logout successful" });
  } catch (error) {
    response.status(500).json({ error: "Internal server error" });
  }
};

export const tokenVerify = catchError(async (req, res, next) => {
  const { token } = req.cookies;

  if (!token)
    res.send({
      mes: "Not Verified",
      user: null,
    });

  const decoded = jwt.verify(token, process.env.SECRET_KEY);
  console.log("Decoded is ", decoded);
  const user = await UserModel.findById(decoded._id).populate("role");
  console.log("The user is ", user);
  if (user) {
    res.send({ msg: "User verified", user: user });
  } else {
    res.send({
      mes: "Not Verified",
      user: null,
    });
  }
});

export const changePassword = catchError(async (req, res, next) => {
  const { oldPassword, newPassword } = req.body;
  const userId = req.user._id;

  try {
    const updatedUser = await userService.changePassword(
      userId,
      oldPassword,
      newPassword
    );
    if (!updatedUser) {
      return next(new ErrorHandler("Invalid old password", 400));
    }

    updatedUser.firstTimePasswordReset = "Y";
    await updatedUser.save();

    res
      .status(200)
      .json({ message: "Password changed successfully", user: updatedUser });
  } catch (error) {
    next(error);
  }
});

export const getAllUsers = catchError(async (req, res, next) => {
  const userId = req.user._id;

  try {
    const users = await userService.getAllUsers(userId);
    res.status(200).json({ users: users });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

export const deleteUser = catchError(async (req, res, next) => {
  const userId = req.user._id;
  const userIdToDelete = req.params.userId;

  try {
    const deletedUser = await userService.deleteUser(userId, userIdToDelete);
    if (!deletedUser) {
      return next(new ErrorHandler("User not found", 404));
    }

    res.status(200).json({ message: "User deleted successfully" });
  } catch (error) {
    next(error);
  }
});

//response.end('<h1> Login </h1>');
export const profile = (request, response) => {
  // const token = request.headers["authorization"];
  // if (verifyToken(token)) {
  //   response.status(SUCCESS_CODE).json({ message: "Profile View" });
  // } else {
  //   response.status(AUTH_FAIL).json({ message: "Authorization Fails..." });
  // }
  console.log("Auth ");
};
export const remove = (request, response) => {};
