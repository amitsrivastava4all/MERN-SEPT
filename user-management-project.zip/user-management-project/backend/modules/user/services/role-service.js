import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { RoleModel } from "../models/role-schema.js";
import { PermissionModel } from "../models/permission-schema.js";
import { UserModel } from "../models/user-schema.js";

export const roleService = {
  async createRole(roleData) {
    const hasAddRolePermission = await this.userHasPermission(
      roleData.userId,
      "AddRole"
    );
    if (!hasAddRolePermission) {
      throw new ErrorHandler(
        "User does not have permission to add a new role",
        403
      );
    }
    const existingRole = await RoleModel.findOne({ name: roleData.name });

    if (existingRole) {
      throw new ErrorHandler("Role already exists", 409);
    }
    const permissionNames = roleData.permissions || [];
    const permissions = await PermissionModel.find({
      name: { $in: permissionNames },
    });

    const permissionIds = permissions.map((permission) => permission._id);

    const newRole = await RoleModel.create({
      ...roleData,
      permissions: permissionIds,
    });

    return newRole;
  },

  async updateRole(roleId, updatedData) {
    const updatedRole = await RoleModel.findByIdAndUpdate(roleId, updatedData, {
      new: true,
    });
    if (!updatedRole) {
      throw new ErrorHandler("Role not found", 404);
    }
    return updatedRole;
  },

  async deleteRole(roleId) {
    const deletedRole = await RoleModel.findByIdAndDelete(roleId);
    if (!deletedRole) {
      throw new ErrorHandler("Role not found", 404);
    }
  },

  async assignPermissionsToRole(roleId, permissionNames) {
    const role = await RoleModel.findById(roleId);
    if (!role) {
      throw new ErrorHandler("Role not found", 404);
    }

    const permissions = await PermissionModel.find({
      name: { $in: permissionNames },
    });
    if (!permissions || permissions.length === 0) {
      throw new ErrorHandler("Permissions not found", 404);
    }
    const newPermissions = permissions.map((permission) => permission._id);
    role.permissions = [...role.permissions, newPermissions];
    return await role.save();
  },

  async userHasPermission(userId, permissionName) {
    const user = await UserModel.findById(userId).populate({
      path: "role",
      populate: {
        path: "permissions",
        model: "permissions",
      },
    });

    if (!user) {
      throw new ErrorHandler("User not found", 404);
    }

    const hasPermission = user.role.some((role) =>
      role.permissions.some((permission) => permission.name === permissionName)
    );

    return hasPermission;
  },
};
