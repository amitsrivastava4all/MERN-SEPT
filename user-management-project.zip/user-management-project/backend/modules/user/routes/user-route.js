import express from "express";
import {
  changePassword,
  deleteUser,
  getAllUsers,
  login,
  logout,
  profile,
  register,
  remove,
  tokenVerify,
} from "../controllers/user-controller.js";
import { isAuthenticated } from "../../../middlewares/auth.js";
import { rbacMiddleware } from "../../../middlewares/rbac-middleware.js";
export const userRouter = express.Router();
userRouter.post("/login", login);
userRouter.post("/logout", isAuthenticated, logout);
userRouter.post("/register",  register);
userRouter.get("/token-verify", tokenVerify);
userRouter.get("/profile", isAuthenticated, profile);
userRouter.post("/remove", isAuthenticated, rbacMiddleware, remove);
userRouter.put("/change-password", isAuthenticated, changePassword);
userRouter.get("/all-users", isAuthenticated, getAllUsers);
userRouter.delete("/delete-user/:userId", isAuthenticated, deleteUser);
