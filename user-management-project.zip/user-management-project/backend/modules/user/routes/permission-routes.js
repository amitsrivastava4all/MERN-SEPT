import express from "express";
import {
  createPermission,
  getPermissions,
  updatePermission,
  deletePermission,
} from "../controllers/permission-controller.js";
import { isAuthenticated } from "../../../middlewares/auth.js";

const permissionRouter = express.Router();

permissionRouter.post("/", isAuthenticated, createPermission);
permissionRouter.get("/", getPermissions);
permissionRouter.put("/update/:id", updatePermission);
permissionRouter.delete("/delete/:id", deletePermission);

export default permissionRouter;
