import { db } from "./firebase-config.js"
import { collection, addDoc, getDocs, query , doc, getDoc} from "https://www.gstatic.com/firebasejs/10.5.0/firebase-firestore.js"; 
/*
import { collection, addDoc } from "firebase/firestore"; 

// Add a new document with a generated id.
const docRef = await addDoc(collection(db, "cities"), {
  name: "Tokyo",
  country: "Japan"
});
console.log("Document written with ID: ", docRef.id);
*/
export const dbOperations = {
    async addQuestion(questionObject){
        // Async Prg
          try{
           const doc = await  addDoc(collection(db,'questions'), questionObject); // Assign to Async Thread
           return doc;
          }
          catch(err){
            console.log('Error During add a Question ', err);
            throw err;
          }
    },
    async getQuestionById(questionId, callBackFn){
      const docRef = doc(db, "questions", questionId);
      const singleDoc = await getDoc(docRef);
      if (singleDoc.exists()) {
        console.log("Document data:", singleDoc.data());
        callBackFn(singleDoc.data());
      } else {
        // docSnap.data() will be undefined in this case
        console.log("No such document!");
      }
    },

    async getAllQuestions(callBackFn){
      const q = query(collection(db,'questions'));
      const querySnapShots = await getDocs(q);
      querySnapShots.forEach(doc=>{
        console.log('Id is ', doc.id);
       // console.log('Doc is ', doc.data());
        callBackFn({...doc.data(), id:doc.id}); // calling the callback function
      })
    }
}