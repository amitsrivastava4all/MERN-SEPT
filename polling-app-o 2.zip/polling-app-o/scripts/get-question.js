import { dbOperations } from "./db-operations.js";

window.addEventListener('load', ()=>{
    loadQuestion();
});

function loadQuestion(){
   // console.log('Current Location ', location.href);
   const currentURL = location.href;
   const url = new URLSearchParams(currentURL);
   let questionid = 0;
   url.forEach(e=>questionid=e);
   console.log("Question Id is ", questionid);
   document.querySelector('#questionid').innerText = questionid;
   dbOperations.getQuestionById(questionid, printQuestion);
}

function printQuestion(question){
    const div = document.querySelector('#single-question');
   
    const h2 = document.createElement('h2');
    h2.innerText = question.ques;
    div.appendChild(h2);
    createOption(question, div, 'option1');
    createOption(question, div, 'option2');
    createOption(question, div, 'option3');
    createOption(question, div, 'option4');
    
}

function createOption(question, div, key){
    const option1 = document.createElement('input');
    option1.name = 'opt';
    option1.type='radio';
    option1.value = question[key];
    const span = document.createElement('span');
    span.innerText = question[key];
    div.appendChild(option1);
    div.appendChild(span);
    div.appendChild(document.createElement('br'));
}