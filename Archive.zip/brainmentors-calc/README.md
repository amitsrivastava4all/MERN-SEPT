# This is Brain Mentors Calc Package 
## Published by Amit Srivastava
**This contains add , sub functions inside the object **