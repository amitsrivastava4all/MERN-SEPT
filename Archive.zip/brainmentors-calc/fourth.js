console.log('Total ' , arguments.length);
for(let i = 0; i<arguments.length; i++){
    console.log('Arg '+(i+1) + ' ',arguments[i]);
}
// Node Wrapper Function
// function(exports, require, module, __filename, __dirname){

// }