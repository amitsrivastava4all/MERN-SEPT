export const Output = ({result})=>{
    return (<h3>Result is {result}</h3>)
}