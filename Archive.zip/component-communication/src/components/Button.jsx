export const Button = ({val, fn})=>{
    return (<button onClick={fn}>{val}</button>)
}