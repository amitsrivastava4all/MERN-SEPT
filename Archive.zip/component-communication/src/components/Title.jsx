export const Title = ()=>{
    return (<h1>Counter App</h1>)
}