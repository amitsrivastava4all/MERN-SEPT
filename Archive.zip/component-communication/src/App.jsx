import { useState } from "react";
import { Button } from "./components/Button";
import { Output } from "./components/Output";
import { Title } from "./components/Title";

const App = ()=>{
  const [count, setCount] = useState(0);
  const plus = ()=>{
    console.log('Plus is ');
    setCount(count + 1); //
   
  }
  const minus = ()=>{
    console.log('Minus is ');
    setCount(count - 1);
  }
  return (<>
  <Title/>
  <Output result = {count}/>
  <Button fn = {plus} val="+"/> &nbsp;
  <Button fn= {minus} val = "-"/>
  </>
  )
}
export default App;