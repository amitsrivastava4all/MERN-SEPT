const compute = require('../basics');
console.log('Add ', compute.add(10,20));
console.log('Sub ',compute.sub(100,200));