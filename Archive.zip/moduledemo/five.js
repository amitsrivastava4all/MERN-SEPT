console.log('Total ' , arguments.length);
for(let i = 0; i<arguments.length; i++){
    console.log('Arg '+(i+1) + ' ',arguments[i]);
}