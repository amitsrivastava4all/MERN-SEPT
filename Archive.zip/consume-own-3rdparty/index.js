import calc from 'brainmentors-calc';
console.log(calc.add(10,20));
console.log(calc.sub(100,200));