import { useState } from "react";

const App = ()=>{
  console.log('App Component Call Again...');
  const [count, setCount] =useState(0); // 0 is initial value of state
  const [val, setVal] = useState("");
  //let count = 0; // Local Variable
  const plus = ()=>{
    //count++;
   // setCount((prev, next)=>prev+1);
    setCount(count + 1);
    console.log('Plus Call ', count);
   
  }
  const computeIt = ()=>{
    //const r = eval(val); //  val expression as an old value
    //setVal(""+r);
    setVal(""+ (eval(val)));
  }

  const getExpression = ()=>{
    setVal("2+3*5");
  }

  return (<div>
    <h1>Counter App</h1>
    <h2>Count Value is {count}</h2>
    <h3>Result is {val}</h3>
    <button onClick= {getExpression} >Get Expression</button>
    <button onClick= {plus} >+</button>
    <button onClick= {computeIt} >=</button>


  </div>)
}
export default App;

