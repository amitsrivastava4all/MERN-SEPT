import React from 'react'
import {useSelector} from 'react-redux';
export const Message = ({value}) => {
  const state = useSelector(state=>state.counterReducer);
  console.log('State is ', state);
  return (
    <h1>Counter Value is {state.counter} </h1>
  )
}
