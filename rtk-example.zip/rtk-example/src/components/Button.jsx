import React from 'react'
import { minus, plus } from '../redux/counter-slice'
import {useDispatch} from 'react-redux';

export const Button = ({value}) => {
  const dispatch = useDispatch();
  return (
    <button onClick={()=>{
      dispatch(value=='+'?plus(5):minus(2));
    }} className='btn btn-primary me-2'>{value}</button>
  )
}
