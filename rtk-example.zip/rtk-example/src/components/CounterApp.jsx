import { Button } from "./Button"
import { Message } from "./Message"

export const CounterApp = ()=>{
    return (<>
    <Message value = "0"/>
        <Button value = "+"/>
        <Button value ="-"/>
    </>)
}