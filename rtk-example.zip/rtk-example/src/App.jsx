import { CounterApp } from "./components/CounterApp";

const App = ()=>{
  return (<div className="container">
    <h1>RTK Example</h1>
    <CounterApp/>
  </div>)
}
export default App;