import {createSlice} from '@reduxjs/toolkit';
const counterSlice = createSlice({
 name:'CounterSlice',
 initialState:{counter:0},
 reducers:{
    // Action Type (plus, minus)
    // UI - action
    // store - state
    plus(state, action){
        console.log('Plus Call ', action);
        state.counter = state.counter + action.payload; // Immer
    },
    minus(state, action){
        state.counter = state.counter - 1;
    }
 }
});
// export - more than 1 (Need to Destructure)
// export default - exactly 1 (No Need Destructure)
export const {plus, minus} = counterSlice.actions; // Consume by UI (Components)
export default counterSlice.reducer; // Consume By Store
// Store updated by Reducer , so Reducer will connect to the store.
