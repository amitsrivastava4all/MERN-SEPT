import { userService } from "../services/user-service.js";
import { AppConstants } from "../../../shared/utils/constants/config.js";
import jwt from "jsonwebtoken";
import { loadMessageBundle } from "../../../shared/utils/i18n/message-reader.js";
import { generateToken, verifyToken } from "../../../shared/utils/token.js";
import { catchError } from "../../../middlewares/catchError.js";
import ErrorMiddleWare from "../../../middlewares/Error.js";
import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { sendToken } from "../../../shared/utils/sendToken.js";
import { RoleModel } from "../models/role-schema.js";
import { UserModel } from "../models/user-schema.js";
const { FILE_NOT_FOUND, SERVER_INTERNAL_ERROR, AUTH_FAIL } =
  AppConstants.ERROR_CODES;
const { SUCCESS_CODE } = AppConstants;
const loadBundle = () => {
  const messages = loadMessageBundle();
  return messages;
};
export const register = catchError(
  async (request, response, next) => {
    const userData = request.body;
    if (userData.email == null && userData.password == null) {
      return next(new ErrorHandler("Please Enter All Fields", 400));
    }
    const doc = await userService.register(userData);
    if (!doc) return next(new ErrorHandler("User Already Exists"), 409);
    sendToken(response, doc, "Registered Successfully", 201);
  }
  //response.end('<h1> Register </h1>');
);
export const login = async (request, response, next) => {
  const messages = loadBundle();
  const { email, password } = request.body;
  console.log("Password ", password);
  if (!email || !password)
    return next(new ErrorHandler("Please Enter All Fields", 400));

  try {
    const user = await userService.login(email, password);

    if (!user) return next(new ErrorHandler("User Not Exists", 401));

    sendToken(response, user, `Welcome back ${user.name}`, 201);
  } catch (error) {
    return next(new ErrorHandler(error.message, 500));
  }
};

export const tokenVerify = catchError(async (req, res, next) => {
  const { token } = req.cookies;
  console.log("The token is ", req.cookies);

  if (!token)
    res.send({
      mes: "Not Verified",
      user: null,
    });

  const decoded = jwt.verify(token, process.env.SECRET_KEY);
  const user = await UserModel.findById(decoded._id).populate("role");
  if (user) {
    res.send({ msg: "User verified", user: user });
  } else {
    res.send({
      mes: "Not Verified",
      user: null,
    });
  }
});

//response.end('<h1> Login </h1>');
export const profile = (request, response) => {
  // const token = request.headers["authorization"];
  // if (verifyToken(token)) {
  //   response.status(SUCCESS_CODE).json({ message: "Profile View" });
  // } else {
  //   response.status(AUTH_FAIL).json({ message: "Authorization Fails..." });
  // }
  console.log("Auth ");
};
export const remove = (request, response) => {};
