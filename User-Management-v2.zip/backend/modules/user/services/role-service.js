import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { RoleModel } from "../models/role-schema.js";
import { PermissionModel } from "../models/permission-schema.js";

export const roleService = {
  async createRole(roleData) {
    const existingRole = await RoleModel.findOne({ name: roleData.name });
    if (existingRole) {
      throw new ErrorHandler("Role already exists", 409);
    }
    return await RoleModel.create(roleData);
  },

  async getRoles() {
    return await RoleModel.find();
  },

  async updateRole(roleId, updatedData) {
    const updatedRole = await RoleModel.findByIdAndUpdate(roleId, updatedData, {
      new: true,
    });
    if (!updatedRole) {
      throw new ErrorHandler("Role not found", 404);
    }
    return updatedRole;
  },

  async deleteRole(roleId) {
    const deletedRole = await RoleModel.findByIdAndDelete(roleId);
    if (!deletedRole) {
      throw new ErrorHandler("Role not found", 404);
    }
  },

  async assignPermissionsToRole(roleId, permissionNames) {
    const role = await RoleModel.findById(roleId);
    if (!role) {
      throw new ErrorHandler("Role not found", 404);
    }

    const permissions = await PermissionModel.find({
      name: { $in: permissionNames },
    });
    if (!permissions || permissions.length === 0) {
      throw new ErrorHandler("Permissions not found", 404);
    }

    role.permissions = permissions.map((permission) => permission._id);
    return await role.save();
  },
};
