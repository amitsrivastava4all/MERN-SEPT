import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import { PermissionModel } from "../models/permission-schema.js";

export const permissionService = {
  async createPermission(permissionData) {
    const existingPermission = await PermissionModel.findOne({
      name: permissionData.name,
    });
    if (existingPermission) {
      throw new ErrorHandler("Permission already exists", 409);
    }
    return await PermissionModel.create(permissionData);
  },

  async getPermissions() {
    return await PermissionModel.find();
  },

  async updatePermission(permissionId, updatedData) {
    const updatedPermission = await PermissionModel.findByIdAndUpdate(
      permissionId,
      updatedData,
      { new: true }
    );
    if (!updatedPermission) {
      throw new ErrorHandler("Permission not found", 404);
    }
    return updatedPermission;
  },

  async deletePermission(permissionId) {
    const deletedPermission = await PermissionModel.findByIdAndDelete(
      permissionId
    );
    if (!deletedPermission) {
      throw new ErrorHandler("Permission not found", 404);
    }
  },
};
