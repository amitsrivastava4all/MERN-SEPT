import ErrorHandler from "../../../shared/utils/ErrorHandler.js";
import {
  comparePassword,
  passwordHashing,
} from "../../../shared/utils/password-hash.js";
import { PermissionModel } from "../models/permission-schema.js";
import { RoleModel } from "../models/role-schema.js";
import { UserModel } from "../models/user-schema.js";

export const userService = {
  async register(userData) {
    try {
      console.log("User Data in Service ", userData);
      const existingUser = await UserModel.findOne({ email: userData.email });
      console.log("User in Service is ", existingUser);

      if (existingUser) {
        return null;
      }

      let roleIds;
      if (!userData.role) {
        const defaultRole = await RoleModel.findOne({ name: "USER" });
        roleIds = [defaultRole._id];
      } else {
        const role = await RoleModel.findOne({ name: userData.role });
        if (!role) {
          throw new Error("Role not found");
        }
        roleIds = [role._id];

        if (role.name === "ADMIN") {
          const allRoles = await RoleModel.find();
          roleIds = allRoles.map((role) => role._id);
        }
      }

      const newUser = await UserModel({ ...userData, role: roleIds }).save();
      console.log("New user created: ", newUser);
      return newUser;
    } catch (err) {
      throw err;
    }
  },

  async login(email, password) {
    // filter by email
    // User Info get , then populate role
    const user = await UserModel.findOne({ email })
      .select("+password") // and get the password key
      .populate("role");

    if (!user) {
      throw new ErrorHandler("User Not Exists", 401);
    }

    const isMatch = await comparePassword(password, user.password);

    if (!isMatch) {
      throw new ErrorHandler("Incorrect Email or Password", 401);
    }

    return user;
  },
};
