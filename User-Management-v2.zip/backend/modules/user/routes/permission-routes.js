import express from "express";
import {
  createPermission,
  getPermissions,
  updatePermission,
  deletePermission,
} from "../controllers/permission-controller.js";

const permissionRouter = express.Router();

permissionRouter.post("/", createPermission);
permissionRouter.get("/", getPermissions);
permissionRouter.put("/update/:id", updatePermission);
permissionRouter.delete("/delete/:id", deletePermission);

export default permissionRouter;
