import express from "express";
import {
  login,
  profile,
  register,
  remove,
  tokenVerify,
} from "../controllers/user-controller.js";
import { isAuthenticated } from "../../../middlewares/auth.js";
import { rbacMiddleware } from "../../../middlewares/rbac-middleware.js";
export const userRouter = express.Router();
userRouter.post("/login", login);
userRouter.post("/register", register);
userRouter.get("/token-verify", tokenVerify);
userRouter.get("/profile", isAuthenticated, profile);
userRouter.post("/remove", isAuthenticated, rbacMiddleware, remove);
