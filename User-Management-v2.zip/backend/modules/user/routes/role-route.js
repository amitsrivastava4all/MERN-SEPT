import express from "express";
import {
  createRole,
  getRoles,
  updateRole,
  deleteRole,
  assignPermissionsToRole,
} from "../controllers/role-controller.js";
import { isAuthenticated } from "../../../middlewares/auth.js";

const roleRouter = express.Router();

roleRouter.post("/", isAuthenticated, createRole);
roleRouter.get("/", isAuthenticated, getRoles);
roleRouter.put("/update/:id", isAuthenticated, updateRole);
roleRouter.delete("/delete/:id", isAuthenticated, deleteRole);
roleRouter.put(
  "/assign-permissions/:id",
  isAuthenticated,
  assignPermissionsToRole
);

export default roleRouter;
