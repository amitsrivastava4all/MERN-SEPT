// store.js
import { configureStore } from "@reduxjs/toolkit";
import userSlice from "../shared/redux/user-slice";
import roleSlice from "../shared/redux/role-slice";
import permissionSlice from "../shared/redux/permission-slice";

const store = configureStore({
  reducer: {
    user: userSlice,
    role: roleSlice,
    permission: permissionSlice,
  },
});

export default store;
