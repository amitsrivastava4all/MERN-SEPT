// import React from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import LoginPage from "./modules/auth/LoginPage.jsx";
import ProtectedRoute from "./shared/components/ProtectedRoute.jsx";
import AdminPage from "./modules/admin/pages/AdminPage.jsx";
import UserPage from "./modules/user/pages/UserPage.jsx";
import { AuthContext } from "./AuthContext.jsx";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useContext, useEffect } from "react";
import { verifyToken } from "./shared/services/api-client.js";
// import { Login } from "./modules/user/components/Login.jsx";
// import LoginPage from "./modules/auth/LoginPage.jsx";

function App() {
  // const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loginContext } = useContext(AuthContext);

  useEffect(() => {
    const verify = async () => {
      const userData = await verifyToken();
      console.log("USer data si safsd", userData);
      if (userData.user) {
        loginContext(userData);
        const hasAdminRole = userData.user.role.some(
          (role) => role.name === "ADMIN"
        );
        const hasUserRole = userData.user.role.some(
          (role) => role.name === "USER"
        );
        console.log("This is the condition ", hasAdminRole, hasUserRole);
        if (hasAdminRole && hasUserRole) {
          navigate("/admin");
        } else if (hasUserRole) {
          navigate("/user");
        }
      }
    };
    verify();
  }, []);
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute allowedRoles={["ADMIN"]}>
              <AdminPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/user"
          element={
            <ProtectedRoute allowedRoles={["USER", "ADMIN"]}>
              <UserPage />
            </ProtectedRoute>
          }
        />
        {/* Other routes */}
      </Routes>
      <ToastContainer />
    </>
  );
}

export default App;
