// import { Login } from "../components/Login";
// import { Profile } from "../components/Profile"
import { Register } from "../components/Register";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import TabPanel from "@mui/lab/TabPanel";
import TabContext from "@mui/lab/TabContext";
import { useState } from "react";
import AddUser from "../../admin/components/AddUser.jsx";
// import Box from '@mui/material/Box';
const UserPage = () => {
  const [value, setValue] = useState(0);

  const tabChange = (event, newValue) => {
    console.log("Tab Change ", newValue);
    setValue(newValue);
  };
  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            User Management System
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>
      <TabContext value={value}>
        <Tabs onChange={tabChange} aria-label="basic tabs example">
          <Tab label="Login" value="0" />
          <Tab label="Register" value="1" />
        </Tabs>
        <TabPanel value="0">
          <AddUser />
        </TabPanel>
        <TabPanel value="1">
          <Register />
        </TabPanel>
      </TabContext>
    </>
  );
};

export default UserPage;
