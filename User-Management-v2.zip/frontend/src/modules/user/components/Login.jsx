import { useContext, useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../../AuthContext.jsx";
import { login } from "../../../shared/services/api-client.js";
export const Login = () => {
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();
  const { login: setAuthData } = useContext(AuthContext);

  const handleLogin = async (credentials) => {
    try {
      const userData = await login(credentials);
      setAuthData(userData);

      navigate("/user"); // Redirect to the user page upon successful login
    } catch (error) {
      console.error("Login failed:", error);
      // Handle login error
    }
  };

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  return (
    <>
      <p>Login</p>
      <TextField id="outlined-basic" label="Email" variant="outlined" />
      <br />
      <OutlinedInput
        id="outlined-adornment-password"
        type={showPassword ? "text" : "password"}
        endAdornment={
          <InputAdornment position="end">
            <IconButton
              aria-label="toggle password visibility"
              onClick={handleClickShowPassword}
              edge="end"
            >
              {showPassword ? <VisibilityOff /> : <Visibility />}
            </IconButton>
          </InputAdornment>
        }
        label="Password"
      />
      <br />
      <Button onClick={() => handleLogin()} variant="contained">
        Login
      </Button>
      &nbsp;
      <Button variant="contained">Clear All</Button>
    </>
  );
};
