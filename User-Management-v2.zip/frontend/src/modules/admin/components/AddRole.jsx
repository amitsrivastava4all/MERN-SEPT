import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Box, TextField, Button, Typography } from "@mui/material";
import { toast } from "react-toastify";
import { addNewRole } from "../../../shared/redux/role-slice";

const AddRole = () => {
  const dispatch = useDispatch();
  const AddRoleStatus = useSelector((state) => state.role.status);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newRole = { name, desc };
    console.log("New Role is ", newRole);
    const resultAction = await dispatch(addNewRole(newRole));
    if (addNewRole.fulfilled.match(resultAction)) {
      console.log("Role Added Successfully");
      toast.success("Role Added Successfully");
    } else if (AddRoleStatus === "failed") {
      toast.error(`Error: ${resultAction.payload || "Failed to add role"}`);
    }
    console.log("Status is ", AddRoleStatus);
    console.log(newRole);
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      minHeight="100vh"
      bgcolor="background.default"
    >
      <Box
        component="form"
        onSubmit={handleSubmit}
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          maxWidth: 400,
          padding: 4,
          bgcolor: "background.paper",
          borderRadius: 2,
          boxShadow: 3,
        }}
      >
        <Typography variant="h5" gutterBottom>
          Add Role
        </Typography>
        <TextField
          label="Role Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          margin="normal"
          required
        />
        <TextField
          label="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          margin="normal"
          required
        />
        <Button
          type="submit"
          variant="contained"
          color="primary"
          sx={{ marginTop: 2 }}
        >
          Add Role
        </Button>
      </Box>
    </Box>
  );
};

export default AddRole;
