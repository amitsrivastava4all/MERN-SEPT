import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
// import { addUser } from "./api-client";
import { register } from "../services/api-client";

export const addNewUser = createAsyncThunk(
  "user/addNewUser",
  async (userData, thunkAPI) => {
    try {
      const newUser = await register(userData);
      return newUser;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.message);
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState: {
    users: [],
    status: "idle",
    error: null,
  },
  reducers: {
    addUserSuccess: (state, action) => {
      state.users.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(addNewUser.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addNewUser.fulfilled, (state, action) => {
        state.status = "success";
        state.users.push(action.payload);
      })
      .addCase(addNewUser.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const { addUserSuccess } = userSlice.actions;

export default userSlice.reducer;
