import {createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import { apiCall } from '../utils/api-client';

export const getAllJobs = createAsyncThunk("/all-jobs",async ()=>{
  // API Call
  const response = await apiCall();
  return response.data;
})
const jobSlice = createSlice({
    initialState : {jobs:null, error:null, loading:false},
    name:'jobSlice',
    reducers:{
        // Sync Logic
    },
    extraReducers:(builder)=>{
        builder.addCase(getAllJobs.pending, (state, action)=>{
            state.loading = true;
            console.log('Pending State is ', state, ' Action is ', action);
        }).addCase(getAllJobs.fulfilled, (state, action)=>{
            state.jobs = action.payload;
            state.loading = false;
            console.log(action.payload);
            console.log(typeof action.payload);
            //console.log('Fullfilled State is ', state, ' Action is ', action.payload);
            //console.log('Fullfilled ', JSON.parse(action.payload), ' Type ', typeof action.payload);
        }).addCase(getAllJobs.rejected, (state, action)=>{
            state.error = action.payload;
            state.loading = false;
            console.log('Rejected State is ', state, ' Action is ', action);
        })
    }
});
export default jobSlice.reducer;