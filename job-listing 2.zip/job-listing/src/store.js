import {configureStore} from '@reduxjs/toolkit';
import jobReducer from './redux/job-slice';
export const store = configureStore({
    reducer:{jobReducer:jobReducer}
});