import React from 'react'

export const Job = ({currentjob}) => {
  return (
    <div>{currentjob.title} &nbsp; &nbsp;{currentjob.description}
    <p>Location : {currentjob.location}</p>
    <p>Perks : {currentjob.perks}</p>
    <p>Salary Range :{currentjob.salaryRange.currency} {currentjob.salaryRange.from}- {currentjob.salaryRange.to}</p>
    <hr/>
    </div>
  )
}
