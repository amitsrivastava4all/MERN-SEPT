import React, { useEffect } from 'react'
import { Job } from './Job'
import { apiCall } from '../utils/api-client';
import {useDispatch, useSelector} from 'react-redux';
import { getAllJobs } from '../redux/job-slice';

export const Jobs = () => {
  const dispatch = useDispatch();
  const state = useSelector(state=>state.jobReducer);
  console.log('State is ', state);
  useEffect(()=>{
    dispatch(getAllJobs());
     // apiCall();
  },[]);
  return (
    <div>
        {state.loading && <p>Loading....</p>}
        { state.jobs && state.jobs.jobs.map(singleJob=><Job currentjob = {singleJob}/>)}
    </div>
  )
}
