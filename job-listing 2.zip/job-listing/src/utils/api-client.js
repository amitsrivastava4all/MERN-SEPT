// Network Call
import axios from 'axios';
export const apiCall = async ()=>{
    
    const response = await axios.get(import.meta.env.VITE_JOB_URL);    
    console.log('Response is ', response.data);
    return response;
}