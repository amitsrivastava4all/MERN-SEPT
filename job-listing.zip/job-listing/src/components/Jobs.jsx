import React, { useEffect } from 'react'
import { Job } from './Job'
import { apiCall } from '../utils/api-client';

export const Jobs = () => {
  useEffect(()=>{
      apiCall();
  },[]);
  return (
    <div>
        <Job/>
        <Job/> 
        <Job/>
    </div>
  )
}
