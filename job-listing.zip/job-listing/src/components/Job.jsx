import React from 'react'

export const Job = () => {
  return (
    <div>Single Job</div>
  )
}
