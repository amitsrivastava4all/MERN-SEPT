import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
//import './App.css'
import { Jobs } from './components/Jobs'

function App() {
  return (<Jobs/>)
  
}

export default App
