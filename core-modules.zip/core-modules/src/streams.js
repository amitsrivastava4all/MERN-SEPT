import fs from 'fs';
const bigFilePath = '/Users/amitsrivastava/Documents/big-file-path/bigger.mp4';
const bigFilePath2 = '/Users/amitsrivastava/Documents/big-file-path/bigger2.mp4';
// fs.readFile(bigFilePath, (err, buffer)=>{
//     if(err){
//         console.log('Unable to read big file ', err);
//     }
//     else{
//         console.log('Data is ', buffer);
//     }
// })
const stream = fs.createReadStream(bigFilePath);
const wstream = fs.createWriteStream(bigFilePath2);
stream.pipe(wstream);
stream.on('open', ()=>{
    console.log('copy start in Progress...')
})
// stream.on('data', chunk=>{
//     wstream.write(chunk);
//     //console.log('Chunk ', chunk);
// })
// stream.on('end', ()=>{
//     console.log('Stream Ends, Copy Done...');
// })
stream.on('close', ()=>{
    console.log('Stream Close.. Copy Done.')
})
//console.log('Code Ends....');