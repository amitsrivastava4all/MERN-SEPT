import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
function getCurrentDir(){
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    //console.log('Current Dir name ', __dirname);
    return __dirname;
}
// Async 
// file path
const rootDir = path.normalize(getCurrentDir()+"/..");
const fullPath = path.join(rootDir, 'samples/hello.txt');
try{
const result= fs.readFileSync(fullPath); // Sync (Blocking Way)
console.log('Sync Result is ******* ', result.toString());
}
catch(err){
    console.log('Error During File Read in Sync Way ', err);
}
console.log('############### I am Done After Sync ###################');
// Non Blocking Way
fs.readFile(fullPath, (err, buffer)=>{
    if(err){
        console.log('Unable to read the file', err);
    }
    else{
        console.log('Content is ', buffer.toString());
    }
})
console.log('$$$$$$$$$$$$ I am Done After Async ###################');
//console.log('Current dir path ', __dirname);
//console.log(import.meta.url);

//fs.readFile()