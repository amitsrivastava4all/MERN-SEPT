import express from 'express';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { userRoutes } from './modules/user/routes/user-route.js';
dotenv.config();

const app = express();
// app - small 
// middleware - it is just a function (request, response, next)
// app.use(middlewares)
app.use(express.json());
app.use('/', userRoutes);
const server= app.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log(chalk.red.bold.underline('Server Crash '), err);
    }
    else{
        console.log(chalk.green.bold.underline('Server Up and Running '), server.address().port);
    }
})